#!/usr/bin/env python3
# Chatbot.py

import time
import pickle
import random
import os
import sys

__author__ = 'Peter Maar'
__version__ = '0.1.0'

thingsToSayOld = []
smartSayDict = {}


def processInput(inputToProcess):
    """Takes a string in. The string contains: BotLastSaid\n\n\n:::\n\n\nUsersNewReply"""
    botSaid = inputToProcess[:inputToProcess.find("\n\n\n:::\n\n\n")]
    userSaid = inputToProcess[inputToProcess.find("\n\n\n:::\n\n\n")+9:]
    global thingsToSayOld
    global smartSayDict

    print("Bot:", botSaid, " | ", "User said:", userSaid)

    try:
        loadmem()
    except FileNotFoundError:
        continueRun = ""
        while continueRun.lower() != "y":
            continueRun = input("Looks like this program hasn't been run before. This program will generate a few files where it is located, so it is reccomended it is in a folder by itself, and executed from that directory.\nIs the program set up correctly? (y/n): ")
            if continueRun.lower() == "n":
                input("The program will now exit. Please move the file to a folder on its own, and execute in that directory.\nPress any key to exit...")
                exit()
        print("Great! Creating files and starting program.")
        setDefaultMem()
        savemem()
        time.sleep(1)
        print("\n\n\n\n\n\n\n\n\n\n") # Put some space betwen this message and the formal start

    if safeToStore(userSaid) and  botSaid.lower() != "what is your name?" and botSaid.lower() != "who are you?" and botSaid.lower() != "what time is it?": # Protect built-in dict. entries
        thingsToSayOld.append(userSaid)  # Store the phrase the user said
        smartSayDict[botSaid.lower()] = userSaid  # Store the last interaction
        savemem()

    sr = specialResponse(userSaid.lower())
    if sr != 0:
        return sr

    if userSaid.lower() in smartSayDict:  # If what the user said is a key in smartSayDict, return the value at that key
        return smartSayDict[userSaid.lower()]
    else:
        return thingsToSayOld[random.randint(0, len(thingsToSayOld)-1)]





def specialResponse(srIn):
    """Returns a special response to srIn. srIn should be a lowercase string. If there is no special response, returns 0"""
    if srIn == "what do you know?":
        print(str(thingsToSayOld) + "\n" + str(smartSayDict))  # Print to the console, but don't return/reply it
        return 0
    elif srIn.find("what time is it?") != -1:
        return currentTime()
    else:
        return 0






def currentTime():
    hour = time.localtime().tm_hour
    minute = time.localtime().tm_min
    if minute < 10:
        minute = "0" + str(minute)
    else:
        minute = str(minute)
    if hour > 12:
        hour -= 12
        return str(hour) + ":" + minute + " PM"  # Minute is a string, to let us add a 0 to the beginning of it if needed
    else:
        return str(hour) + ":" + minute + " AM"  # Minute is a string, to let us add a 0 to the beginning of it if needed


def savemem():
    global thingsToSayOld
    global smartSayDict
    f1 = open(sys.path[0] + '/thingsToSayOld.pickle', 'wb')
    pickle.dump(thingsToSayOld, f1, pickle.HIGHEST_PROTOCOL) #Higher protocols may reduce compatibility, but are faster and create smaller files
    f1.close()
    f2 = open(sys.path[0] + '/smartSayDict.pickle', 'wb')
    pickle.dump(smartSayDict, f2, pickle.HIGHEST_PROTOCOL) #Higher protocols may reduce compatibility, but are faster and create smaller files
    f2.close()

def loadmem():
    global thingsToSayOld
    global smartSayDict
    f1 = open(sys.path[0] + '/thingsToSayOld.pickle', 'rb')
    thingsToSayOld = pickle.load(f1)
    f1.close()
    f2 = open(sys.path[0] + '/smartSayDict.pickle', 'rb')
    smartSayDict = pickle.load(f2)
    f2.close()

def setDefaultMem():
    global thingsToSayOld
    global smartSayDict
    thingsToSayOld = ["Yes", "No", "Oh", "Oh, okay", "What?", "I'm confused", "so...?", "What do you mean?", "Please clarify", "I don't get it", "meaning...", "Don't Forget to Be Awesome", "I love memes", "I love the internet", "Python is pretty cool, don't you agree? It may be a little limited in some aspects, but it's so easy to use!", "What's the weather like?", "How's the weather?", "How are you doing?", "How are you?"]
    #  "Who?", "What?", "When?", "Where?", "Why?", "How?", #asked way too much
    smartSayDict = {"hello!" : "Hi!", "hello" : "Hi", "hi!" : "Hello!", "hi" : "Hello", "how are you doing?" : "Very well, how are you?", "what is your name?": "My name is Sapiens, who are you?", "who are you?" : "I'm Sapiens, what's your name?", "bye" : "Bye", "bye!" : "Bye!", "i gtg" : "k", "gtg" : "k", "ttyl" : "ttyl"}  # A dictionary of the interactons in the format of "question : reply". Interactions will be added as "botMsg : usrReply" This will be referenced in reverse when the user types something


def safeToStore(inputString):
    return inputString.lower() != '' and inputString.lower().find("sapiens") == -1 and inputString.lower().find("name") == -1 and inputString.lower().find("i'm") == -1 and inputString.lower().find("i am") == -1 and inputString.lower().find("to leave") == -1 and inputString.lower().find("bye") == -1 and inputString.lower().find("ttyl") == -1 and inputString.lower().find("gtg") == -1 and inputString.lower().find("what do you know?") == -1 #Don't store if they said something about sapiens or names or leaving or 'what do you know


if __name__ == "__main__":
    # execute only if run as a script
    for i in range(10):
        stuff = input("Bot said: ") + "\n\n\n:::\n\n\n" + input("Human says: ")
        print(processInput(stuff))
